<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Nieuwsbrief</title>
</head>
<body>
<h1>Bedankt</h1>
</body>
</html>
<?php /**PATH C:\Users\PS208985\TemperatuurData\TemperatuurData\resources\views/bedankt.blade.php ENDPATH**/ ?>