<!DOCTYPE html>
<html lang='nl' xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset='UTF-8'>
    <title>2010 temperaturen</title>
    <style>
        *{

            font-family: "Comic Sans MS", sans-serif;
            font-size: 25px}
        table{
            border: 1px solid black;
        }
        td{text-align: right}
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

</head>
<body>
<form action="overzicht" method="get">
    Maand: <select name="maand" onchange="submit()" >
        <?php for($i = 0; $i <= 12; $i++): ?>
        <option value="<?php echo e($i); ?>" <?php if($i == $maand): ?> selected <?php endif; ?>><?php echo e($maandnamen[$i]); ?></option>
        <?php endfor; ?>
    </select>

    <div class="meting">
        <input type="radio" id="Celsius" name="Temperature" value="C" <?php if($Temperature == 'C'): ?> checked <?php endif; ?> onclick="submit()">
        <label for="C">Celsius</label>
        <input type="radio" id="Farenheit" name="Temperature" value="F" <?php if($Temperature == 'F'): ?> checked <?php endif; ?> onclick="submit()">
        <label for="F">Farenheit</label>
        <input type="radio" id="Kelvin" name="Temperature" value="K" <?php if($Temperature == 'K'): ?> checked <?php endif; ?> onclick="submit()">
        <label for="K">Kelvin</label>
        <input type="radio" id="Rankine" name="Temperature" value="R" <?php if($Temperature == 'R'): ?> checked <?php endif; ?> onclick="submit()">
        <label for="Rankine">Rankine</label>
        <input type="radio" id="Réaumur" name="Temperature" value="Ré" <?php if($Temperature == 'Ré'): ?> checked <?php endif; ?> onclick="submit()">
        <label for="Réaumur">Réaumur</label>
    </div>

</form>
<form action="nieuwsbrief" method="post" novalidate>
<?php echo csrf_field(); ?>
    <label>E-mailadres:</label>
    <input type="email" required name="emailadres"/>
    <button type="submit">Vraag nieuwsbrief aan</button>
</form>
<?php $maandnamen=array("Selecteer maand","Januari","Februari","Maart","April","Mei","Juni",
    "Juli","Augustus","September","Oktober","November","December");?>
<h1><?php echo e($maandnamen[$maand]); ?></h1>

<table >
    <tr><th>Dag</th><th>Minimum</th><th>Maximum</th></tr>
    <?php $__currentLoopData = $metingen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($m->dagnr); ?> </td>
        <td> <?php echo e(Number_format($m->minimum,1)); ?> <?php if($Temperature != "K"): ?> <?php echo "&deg;" ?> <?php endif; ?> <?php echo e($Temperature); ?> </td>
        <td> <?php echo e(Number_format($m->maximum,1)); ?> <?php if($Temperature != "K"): ?> <?php echo "&deg;" ?> <?php endif; ?> <?php echo e($Temperature); ?> </td>
    </tr>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH C:\Users\PS208985\TemperatuurData\TemperatuurData\resources\views/overzicht.blade.php ENDPATH**/ ?>