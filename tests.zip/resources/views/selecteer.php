<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Temperaturen</title>
</head>
<body>
<form action="overzicht" method="get">
    Maand: <select name="maand">
        <option value="1">Januari</option>
        <option value="2">Februari</option>
        <option value="3">Maart</option>
        <option value="4">April</option>
    </select>
    <button type="submit">Overzicht</button>
</form>
</body>
</html>
